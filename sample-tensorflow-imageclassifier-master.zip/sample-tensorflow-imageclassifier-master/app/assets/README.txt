These model checkpoint files are copied from the pre-trained
[MobileNet\_v1 model](https://github.com/tensorflow/models/blob/master/research/slim/nets/mobilenet_v1.md).
